













let pop_song_left = document.getElementById('pop_song_left');
let pop_song_right = document.getElementById('pop_song_right');
let pop_songs = document.getElementsByClassName('pop_songs')[0];


pop_song_right.addEventListener('click', () => {
    pop_songs.scrolleft += 330;
})
pop_song_left.addEventListener('click', () => {
    pop_songs.scrolleft -= 330;
})
